<?php

require_once( 'class-itsec-wordpress-tweaks.php' );
