<?php

require_once( dirname( __FILE__ ) . '/utilities.php' );

ITSEC_Away_Mode_Utilities::create_active_file();
