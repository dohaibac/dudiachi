<?php

require_once( 'class-itsec-ban-users.php' );

ITSEC_Ban_Users::deactivate();
